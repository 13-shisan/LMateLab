# LMateLab 107 杯 Slurm 运行数据附件

快照时间：`2026-09-05T10:56:22+08:00`

本附件对应“算力平台赛道必须另附 Slurm 作业日志、资源使用、排队及运行时间等算力集群运行数据说明”。先阅读 `compute-cluster-run-data.md`，逐作业核对使用 `slurm-job-ledger.csv`。

## 统计结论

- 真实 Slurm Job ID：`218` 个，均已去重；
- 调度终态：`138 completed / 32 failed / 47 cancelled / 1 running`；
- 正式 VASP attempt：`26` 个，其中 Slurm `25 completed / 1 failed`；
- VASP 科学门禁：`21 accepted / 4 rejected / 1 not evaluated`；
- `44` 个网页服务作业是在新版本切换后受控停止，不是功能失败；
- `sbatch --test-only`、Fake Slurm ID、调度前拒绝和没有 Job ID 的取消不计入。

Slurm `COMPLETED` 只说明调度和批脚本层结束，不自动说明 VASP 科学结果有效。VASP 的科学结论必须查看总账中的 `scientific_result` 和 `scientific_reason`。

## 目录

| 路径 | 内容 |
|---|---|
| `root-logs/` | 187 个根作业的 374 个 stdout/stderr 文件 |
| `stage6/` | 4 个 Slurm 适配器子作业的日志、调度 JSON、receipt 和汇总；不含 SQLite |
| `stage7/` | 专属核验 Job `40274` 的 stdout/stderr |
| `vasp-runtime/` | 26 个 VASP attempt 的脱敏运行摘要文件 |
| `slurm-job-ledger.csv` | 218 个作业的统一总账 |
| `lmatelab-107cup-vasp-ledger-20260905.csv` | 26 个 VASP attempt 的资源、时间和科学验收明细 |
| `compute-cluster-run-data.md` | 统计口径、分类、资源与限制说明 |
| `SHA256SUMS.txt` | 附件内其余 562 个文件的 SHA-256 |

总账的 `remote_evidence_files` 列给出 107 服务器上的完整绝对路径，`attachment_files` 列给出本附件中的相对路径。多个位置使用分号分隔。

## 时间和资源说明

VASP 作业的资源请求固定为 `16 CPU + 32 GiB + 1 x RTX5090`。26 个 VASP 作业的排队合计 `624.809 s`、运行合计 `949 s`；25 个实际进入 VASP runner 的作业保留 `/usr/bin/time` wall 和峰值 RSS。

历史 `sacct` 记账无法完整恢复，因此未取得的排队时间、运行时间、实际 CPU/GPU 利用率和 MaxRSS 保持为空或 `unavailable`。没有用日志 mtime、相邻 Job ID 或脚本时限进行估算。证据等级逐项记录在 `scheduler_evidence`。

## 安全与复核

附件不包含正式数据库、JWT、密码、Gitea Token、SSH key、二次验证码、POTCAR、OUTCAR、WAVECAR 或 CHGCAR。VASP runtime 仅保留：

- `stdout.log`
- `stderr.log`
- `runtime-time.txt`
- `vasp-exit-code.txt`
- `job-id.receipt`

核验完整性时，在附件根目录按 `SHA256SUMS.txt` 逐文件重新计算 SHA-256。压缩包自身 SHA-256 另记录在项目说明文档中。
